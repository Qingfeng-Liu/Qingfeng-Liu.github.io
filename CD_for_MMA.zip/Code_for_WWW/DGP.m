function [y,x,mu]=DGP(n,x,theta)
e=normrnd(0,1,n,1);
mu=x*theta;
y=mu+e;
