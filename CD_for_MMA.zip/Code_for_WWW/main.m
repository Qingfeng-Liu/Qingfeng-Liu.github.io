%Sparsity of MMA
%Project Group (Yang Feng, Qingfeng Liu and Ryo Okui)
%Feb 15, 2019. Revised by Qingfeng Liu for WWW, Aug 22, 2021.
%@Columbia.NY
%Publised as
% Yang Feng, Qingfeng Liu, Ryo Okui,
% On the sparsity of Mallows model averaging estimator,
% Economics Letters,
% Volume 187,
% 2020,
% 108916,
% ISSN 0165-1765,
% https://doi.org/10.1016/j.econlet.2019.108916.

rng(0);
m = 5; %Change number of variables
n = 200; %Sample size
s = candidate(zeros(n,m),2); %See the help in the function candidate.
k = size(s,1);

%Change R^2
%You can set Rsq = 1:9 to vary R^2 from 0.1 to 0.9 with increment 0.1.
RSq = 1;
su = sum([1 1 1 1/2 1/2 1/2 1/3 1/3 1/3 1/4 1/4 1/4 1/5 1/5 1/5].^2);
c = ((10/RSq-1)*(su-1))^(-0.5);
j = 10000;
x = [ones(n,1) normrnd(0,1,n,j-1)];
theta = (c*(1:1:j)'.^(-1));
theta(1:15,:) = c*[1 1 1 1/2 1/2 1/2 1/3 1/3 1/3 1/4 1/4 1/4 1/5 1/5 1/5]';
%theta(11:end,:)=0; %For a sparse try.
[y,x,mu] = DGP(n,x,theta);
xm = x(:,1:m);
clear x
clear theta
[bbeta,ee, sighat,w0] = olsE(y,xm,s);
Sigma = sighat;
para.gamma = 1000;
para.p = size(s,1);
para.iterMax = 1e10;
para.epsCon = 1e-10;
para.lambda = Sigma*sum(s,2);

mu_tilde = xm*bbeta;
wCD0 = ones(para.p,1)/para.p;
re = mma_CD(mu_tilde, y, para, wCD0);
wCD = re.w;
bhat_CD = bbeta*wCD;
yhat_CD = xm*bhat_CD;
mse_CD = 1/n*(yhat_CD-mu)'*(yhat_CD-mu);
disp("wCD-the model averaging weight vector")
disp(wCD)



