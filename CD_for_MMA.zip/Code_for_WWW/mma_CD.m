function re = mma_CD(x, y, para, w)
iter = 0;
error = para.epsCon + 1;
%errorlist = zeros(para.iterMax,1);
resi = y-x*w;
wsum = sum(w);
while iter < para.iterMax && error > para.epsCon
    iter = iter + 1;
    wlast = w;
    oldresi = resi;%new line
    for j = 1:para.p 

        wsum = wsum - wlast(j);
        xj = x(:,j);
        resi = resi + xj*wlast(j);
        z = xj'*resi - para.gamma*(wsum-1);
        %z = xj'*resi;
        denom = para.gamma+xj'*xj;
        %denom = xj'*xj;
        zj = z-para.lambda(j);
        w(j) = (zj > 0)*zj/denom;
        %wjj = sign(z)  *(abs(z) - para.lambda(j)) * ((abs(z) - para.lambda(j)) > 0)/denom;
        %w(j) - wjj
        resi = resi - xj*w(j);
        wsum = wsum + w(j);
        
        
      %  toc
%      Next two line get the same result of the above line
%      w(j) = sign(z)  *(abs(z) - para.lambda(j)) * ((abs(z) - para.lambda(j)) > 0)/denom;
%      w(j) = w(j) * (w(j) > 0);
    end
    %error = mean(abs(w-wlast));
    error = (resi-oldresi)'*(resi-oldresi);
end
re.w = w;
re.iter = iter;
re.error = error;
re.memory = monitor_memory_whos( );

    