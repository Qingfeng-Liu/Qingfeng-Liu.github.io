%MMA, JMA and GC
%Written by Qingfeng Liu 
%Based on the program of JMA by Chu-An Liu and Bruce E. Hansen
function [bbeta,ee, sighat,w0]=olsE(y,x,s)

%%
%Note by Chu-An Liu and Bruce E. Hansen
%This Matlab function computes the Mallows Model Average (MMA) and
%  the Jackknife Model Average (JMA) least-squares estimates.
%
%  written by
%  Chu-An Liu and Bruce E. Hansen
%  Department of Economics
%  University of Wisconsin
%
%  Format:
%
%  [betahat,w,yhat,ehat,R2,Cn]=gma(y,x,method,subset,s)
%  or  [betahat,w,yhat,ehat,R2,Cn]=gma(y,x,method,subset)
%
%  Inputs:
%  y           nx1   dependent variable
%  x           nxp   regressor matrix
%  method      1x1   set to 1 for Mallows model average estimates
%                    set to 2 for Jackknife model average estimates
%                    set to 3 for Generalized Cp model average estimates
%  subset      1x1   set to 1 for pure nested subsets
%                    set to 2 for all combinations of subsets
%                    set to 3 for using the selection matrix
%  s           mxp   selection matrix. optional. m: number of models
%                    Example:
%                       Suppose there are 3 candidate models.
%                       Model 1: y=beta1*x1+beta2*x2+e
%                       Model 2: y=beta1*x1+beta3*x3+e
%                       Model 3: y=beta1*x1+beta2*x2+beta4*x4+e
%                       Then s=[1,1,0,0;
%                               1,0,1,0;
%                               1,1,0,1]
%
%  Outputs:
%  betahat     px1   parameter estimate
%  w           mx1   weight vector
%  yhat        nx1   fitted values
%  ehat        nx1   fitted residuals
%  r2          1x1   R-squared
%  cn          1x1   Value of Mallows criterion or Cross-Validation criterion
%
%  Note:
%  For pure nested subsets, the regressors columns should be ordered, with the
%  intercept first and then in order of relevance.
%  For all combinations of subsets, p is less than about 20.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
[n,p]=size(x);
m=length(s(:,1));
w0=ones(m,1)/m;
bbeta=zeros(p,m);
for j=1:m
    ss=ones(n,1)*s(j,:)>0;
    xs=x(ss);
    xs=reshape(xs,n,length(xs)/n);
    betas=(xs'*xs)\(xs'*y);
    sj=s(j,:)>0;
    bbeta(sj,j)=betas;
end
ee=y*ones(1,m)-x*bbeta;
ehat=y-x*((x'*x)\(x'*y));
sighat=(ehat'*ehat)/(n-p);




