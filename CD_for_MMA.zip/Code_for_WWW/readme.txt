Run mian.m for a demo of the Coordinate-wise Descent Algorithm for MMA.

For details refer to

Yang Feng, Qingfeng Liu, Ryo Okui,
On the sparsity of Mallows model averaging estimator,
Economics Letters,
Volume 187,
2020,
108916,
ISSN 0165-1765,
https://doi.org/10.1016/j.econlet.2019.108916.