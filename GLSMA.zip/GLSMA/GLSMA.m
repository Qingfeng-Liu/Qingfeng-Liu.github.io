%GLSMA, with Robinson's method or MLE
%By Qingfeng Liu
%14Oct2016 Revised
%i indicate the method for extimating variance. i = 1, Robinson's method, i = 2, MLE.
%ii indicate the type of criterion, %iii = 1, ?C_I, iii = 2, ?C_?Omega
%permu indicate for type of candidate model set, permu = 1 for nested models,
%permu = 2 for all posible permutations based on x.
%k1 indiacte the variable in x that is used for MLE estimation of variance.
%k2 indicate the tuning parameter of knn.

function [mu_glsma, bhat_glsma, wglsma] = GLSMA(x, y, i, ii, permu, k1, k2)

x0 = x; x2 = x(:,k1); k2 = k2+1;
s0 = candidate(x, permu);
wmse = zeros(k2-1,1);
%% Estimate variances

% Robinson's method
if i == 1
    % Leave-one-out for selecting the optimal knn for rwls(Robinsons WLS)
    for wk = 2:k2
        [~, ~, sigma2, u2] = rwls_loo(x, y, wk);
        Sigma2(:,wk-1) = diag(sigma2);
        wmse(wk-1) = mean((Sigma2(:,wk-1)-u2).^2);
        
    end
    knn = find(wmse==min(wmse))+1;
    %Estimate variances
    [~, ~, sigma2] = rwls(x, y, knn);
    
    % MLE
else
    options = optimset('LargeScale','off','Display','off','MaxFunEvals',10000);
    gamma0 = [0.01 0 1]';
    gamma = fminsearch(@glsl3,gamma0,options,y,x0,x2);
    gamma = abs(gamma);
    [~,~,sigma2] = glsl3(gamma,y,x0,x2);
    sigma2 = diag(sigma2);
end



%%
if ii == 1
    %%%%%%%%%%%%
    % Method 1. ?C_I%
    %%%%%%%%%%%%
    
    [~,bhat_glsma,wglsma] = ma_C1_bar(y,x,s0,sigma2);
    mu_glsma = x*bhat_glsma;
    
    
    %%
else
    %%%%%%%%%%%%%
    % Method 2. ?C_?Omega %
    %%%%%%%%%%%%%
    
    % 1.Transform data with covariance matrx sigma2
    xs = inv(sigma2)^0.5*x;ys = inv(sigma2)^0.5*y;
    
    % 2.do everaging with transformed data
    [~,bhat_glsma,wglsma] = ma_C2_bar(ys,xs,s0);
    mu_glsma = x*bhat_glsma;

end
