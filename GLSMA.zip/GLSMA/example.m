%example for GLSMA 
%for help see GLSMA.m
%By Qingfeng Liu
%14Oct2016 Revised
data = load('testdata.csv');
y = data(:, 1);
x = data(:, 2:end);
[mu_glsma, bhat_glsma, wglsma] = GLSMA(x, y, 2, 2, 1, 2, 10);
