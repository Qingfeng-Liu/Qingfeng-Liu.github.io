function [ll,beta,omega]=glsl3(ab,y,xs,x2)
ab=abs(ab);
a=ab(1);%b=ab(2:6,1);%??????+0.0001
b=ab(2);
sig=a+x2.^4*b;
%sig=a+b*x2.^2;
omega=(sig.*(sig>0.000001)+0.001*(sig<=0.000001));
invomega=diag(1./omega);
beta=(xs'*invomega*xs)\xs'*invomega*y;
ll=-1/2*(log(det(diag(omega)))+y'*(invomega-invomega*xs/(xs'*invomega*xs)*xs'...
    *invomega)*y);
ll=-ll;