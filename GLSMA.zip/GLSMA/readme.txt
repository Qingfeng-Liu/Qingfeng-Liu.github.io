GLSMA.m is a Matlab code to perform the GLSMA estimation with your data set.
For the details of GLSMA, please refer to ”Generalized Least Squares Model Averaging," Qingfeng Liu, Ryo Okui and Arihiro Yoshimura, Econometric Reviews (2016), 35(8-10):1692–1752.

All the files should be put into a same folder and the folder should be added to path.
For help, please run ‘help GLSMA.m’ in your command line.
For an example, please run example.m.

