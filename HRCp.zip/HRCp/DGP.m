function [y,x,mu]=DGP(n,x,theta)
e=normrnd(0,(0.01+x(:,2).^4).^0.5,n,1);
%e=normrnd(0,1,n,1);
mu=x*theta;
y=mu+e;
