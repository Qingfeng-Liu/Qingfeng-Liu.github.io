%Example for HRCp, JMA and MMA estimations by function ma.m
%By Qingfeng Liu
%April, 08, 2018 
n=150;j=10000;
a=.5;
c0=(((3.01)./(1./(0.1:0.1:0.9)-1))/(pi^2/6-1)).^0.5;
rng(0);
c=c0(2);
theta=c*(2*a)^0.5*(1:1:j)'.^(-a-1/2);
R_HRCp=0;R_JMA=0;R_MMA=0;
x=[ones(n,1) normrnd(0,1,n,j-1)];
x0=x;
m=30;
s0=candidate(x(:,1:m),1);
%s0=candidate(x(:,1:m),2);%all the permutations
[y,x,mu]=DGP(n,x0,theta);
[muhat_hrcp,muhat_jma,muhat_mma,bhat_hrcp,...
    bhat_jma,bhat_mma,whrcp,wjma,wmma]=ma(y,x(:,1:m),s0)