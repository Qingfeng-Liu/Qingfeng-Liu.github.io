ma.m is a Matlab code to perform the HRCp, JMA and MMA estimations with your data set.
For the details of HRCp, please refer to "Heteroscedasticity‐robust Cp model averaging." Qingfeng Liu and Ryo Okui, The Econometrics Journal 16.3 (2013): 463-472.

All the files should be put into a same folder and the folder should be added to path.
For help, please run ‘help ma.m’ in your command line.
For an example, please run main.m.

